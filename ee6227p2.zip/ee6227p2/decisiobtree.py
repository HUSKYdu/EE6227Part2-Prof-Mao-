
import graphviz
from sklearn import tree
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math as mt

DF = pd.read_excel('Data_Train.xlsx')
C1 = DF['C1'].values
C2 = DF['C2'].values
C3 = DF['C3'].values
C4 = DF['C4'].values

DF = pd.read_excel('Label_Train.xlsx')
label=DF['label'].values
data=[]
for i in range(0,len(label)):
    sample=[]
    sample.append(C1[i])
    sample.append(C2[i])
    sample.append(C3[i])
    sample.append(C4[i])
    data.append(sample)


x=np.array(data)

clf=tree.DecisionTreeClassifier(criterion='gini')#gini,best
clf.fit(x,label)
print(clf)
print(clf.predict([[1,0,0,1]]))
print(clf.feature_importances_)
dot_data=tree.export_graphviz(clf,out_file=None)
graph=graphviz.Source(dot_data)
graph.render('dtg')
pred=clf.predict(x)


DF = pd.read_excel('Data_test.xlsx')
C1T = DF['C1'].values
C2T = DF['C2'].values
C3T = DF['C3'].values
C4T = DF['C4'].values

testdata=[]
for i in range(0,len(C1T)):
    test=[]
    test.append(C1T[i])
    test.append(C2T[i])
    test.append(C3T[i])
    test.append(C4T[i])
    testdata.append(test)
xtest=np.array(testdata)
print(clf.predict(xtest))

x1=[]
for i in range(0,len(label)):
    x1.append(i+1)
plt.figure(figsize=(15,6))
plt.step(x1,label,c='k',label='Real Class')
plt.step(x1,pred,c='r',label='Predict Class')
plt.title('Prediction Result of Training Data Set Using Decision Tree (Gini Criterion)',fontsize=20)
plt.xlabel('Sample No.',fontsize=20)
plt.ylabel('Class',fontsize=20)
plt.legend(fontsize=20,loc='upper left')
plt.savefig('DTG.svg',dpi=600)
plt.show()
fenzi=0
fenmu=0
for i in range(0,len(label)):
    if label[i]==pred[i]:
        fenzi=fenzi+1
        fenmu=fenmu+1
    else:
        fenmu=fenmu+1
print('The Accuracy is:')
print(fenzi/fenmu)