import matplotlib.pyplot as plt
from sklearn import discriminant_analysis
import pandas as pd
import numpy as np
import math as mt

DF = pd.read_excel('Data_Train.xlsx')
C1 = DF['C1'].values
C2 = DF['C2'].values
C3 = DF['C3'].values
C4 = DF['C4'].values

DF = pd.read_excel('Label_Train.xlsx')
label=DF['label'].values
data=[]
for i in range(0,len(label)):
    sample=[]
    sample.append(C1[i])
    sample.append(C2[i])
    sample.append(C3[i])
    sample.append(C4[i])
    data.append(sample)
x=np.array(data)

fisherclf=discriminant_analysis.LinearDiscriminantAnalysis()
fisherclf.fit(x,label)
pred=fisherclf.predict(x)
DF = pd.read_excel('Data_test.xlsx')
C1T = DF['C1'].values
C2T = DF['C2'].values
C3T = DF['C3'].values
C4T = DF['C4'].values

testdata=[]
for i in range(0,len(C1T)):
    test=[]
    test.append(C1T[i])
    test.append(C2T[i])
    test.append(C3T[i])
    test.append(C4T[i])
    testdata.append(test)
xtest=np.array(testdata)

print(fisherclf.predict(xtest))
print('coefficient')
print(fisherclf.coef_)
print('b value')
print(fisherclf.intercept_)
print('mean vector')
print(fisherclf.means_)
print('total mean vector')
print(fisherclf.xbar_)

x1=[]
for i in range(0,len(label)):
    x1.append(i+1)
plt.figure(figsize=(15,6))
plt.step(x1,label,c='k',label='Real Class')
plt.step(x1,pred,c='r',label='Predict Class')
plt.title('Prediction Result of Training Data Set Using Fisher Discriminant Analysis',fontsize=20)
plt.xlabel('Sample No.',fontsize=20)
plt.ylabel('Class',fontsize=20)
plt.legend(fontsize=20,loc='upper left')
plt.savefig('Fisher.svg',dpi=600)
plt.show()
fenzi=0
fenmu=0
for i in range(0,len(label)):
    if label[i]==pred[i]:
        fenzi=fenzi+1
        fenmu=fenmu+1
    else:
        fenmu=fenmu+1
print('The Accuracy is:')
print(fenzi/fenmu)