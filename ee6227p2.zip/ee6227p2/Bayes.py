import pandas as pd
import numpy as np
import math as mt
import matplotlib.pyplot as plt

DF = pd.read_excel('Data_Train.xlsx')
C1 = DF['C1'].values
C2 = DF['C2'].values
C3 = DF['C3'].values
C4 = DF['C4'].values

DF = pd.read_excel('Label_Train.xlsx')
label=DF['label'].values
data=[]
for i in range(0,len(label)):
    sample=[]
    sample.append(label[i])
    sample.append(C1[i])
    sample.append(C2[i])
    sample.append(C3[i])
    sample.append(C4[i])
    data.append(sample)
miu=[]
rou=[]

for i in range(0,3):
    datacompute=[]
    for m in range(0,len(label)):
        if data[m][0]==i+1:
            datacompute.append(data[m])
    miuone = []
    for j in range(0,4):
        clist=[]
        for k in range(0, len(datacompute)):
            clist.append(datacompute[k][j+1])
        miuone.append(sum(clist)/len(clist))
    miu.append(miuone)

for i in range(0,3):
    datacompute=[]
    for m in range(0,len(label)):
        if data[m][0]==i+1:
            datacompute.append(data[m])
    rouone = []
    for j in range(0,4):
        clist=[]
        for k in range(0, len(datacompute)):
            clist.append(datacompute[k][j+1])
        rouone.append(np.var(clist))
    rou.append(rouone)

pred=[]
for i in range(0,len(label)):
    probability=[]
    for k in range(0,3):
        p=(1/(mt.sqrt(2*mt.pi)*rou[k][0]))*mt.exp(0-round((((data[i][1]-miu[k][0])*(data[i][1]-miu[k][0]))/(2*rou[k][0]*rou[k][0])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][1]))*mt.exp(0-round((((data[i][2]-miu[k][1])*(data[i][2]-miu[k][1]))/(2*rou[k][1]*rou[k][1])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][2]))*mt.exp(0-round((((data[i][3]-miu[k][2])*(data[i][3]-miu[k][2]))/(2*rou[k][2]*rou[k][2])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][3]))*mt.exp(0-round((((data[i][4]-miu[k][3])*(data[i][4]-miu[k][3]))/(2*rou[k][3]*rou[k][3])),2))
        probability.append(p)
    pred.append(1+probability.index(max(probability)))


fenzi=0
fenmu=0
for i in range(0,len(label)):
    if label[i]==pred[i]:
        fenzi=fenzi+1
        fenmu=fenmu+1
    else:
        fenmu=fenmu+1
print('The Accuracy is:')
print(fenzi/fenmu)

DF = pd.read_excel('Data_test.xlsx')
C1T = DF['C1'].values
C2T = DF['C2'].values
C3T = DF['C3'].values
C4T = DF['C4'].values

testdata=[]
for i in range(0,len(C1T)):
    test=[]
    test.append(0)
    test.append(C1T[i])
    test.append(C2T[i])
    test.append(C3T[i])
    test.append(C4T[i])
    testdata.append(test)

testpred=[]
for i in range(0,len(C1T)):
    probability=[]
    for k in range(0,3):
        p=(1/(mt.sqrt(2*mt.pi)*rou[k][0]))*mt.exp(0-round((((testdata[i][1]-miu[k][0])*(testdata[i][1]-miu[k][0]))/(2*rou[k][0]*rou[k][0])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][1]))*mt.exp(0-round((((testdata[i][2]-miu[k][1])*(testdata[i][2]-miu[k][1]))/(2*rou[k][1]*rou[k][1])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][2]))*mt.exp(0-round((((testdata[i][3]-miu[k][2])*(testdata[i][3]-miu[k][2]))/(2*rou[k][2]*rou[k][2])),2))\
       *(1/(mt.sqrt(2*mt.pi)*rou[k][3]))*mt.exp(0-round((((testdata[i][4]-miu[k][3])*(testdata[i][4]-miu[k][3]))/(2*rou[k][3]*rou[k][3])),2))
        probability.append(p)
    testpred.append(1+probability.index(max(probability)))
print('test data predict result is:')
print(testpred)



x=[]
for i in range(0,len(label)):
    x.append(i+1)
plt.figure(figsize=(15,6))
plt.step(x,label,c='k',label='Real Class')
plt.step(x,pred,c='r',label='Predict Class')
plt.title('Prediction Result of Training Data Set Using Bayes Decision Rule',fontsize=20)
plt.xlabel('Sample No.',fontsize=20)
plt.ylabel('Class',fontsize=20)
plt.legend(fontsize=20,loc='upper left')
plt.savefig('bayes.svg',dpi=600)
plt.show()









