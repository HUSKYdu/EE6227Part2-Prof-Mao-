import pandas as pd
import numpy as np
import numpy.linalg
import math as mt
import matplotlib.pyplot as plt

DF = pd.read_excel('Data_Train.xlsx')
C1 = DF['C1'].values
C2 = DF['C2'].values
C3 = DF['C3'].values
C4 = DF['C4'].values

DF = pd.read_excel('Label_Train.xlsx')
label=DF['label'].values
data=[]
datacompute1=[]
for i in range(0,len(label)):
    sample=[]
    sample.append(label[i])
    sample.append(C1[i])
    sample.append(C2[i])
    sample.append(C3[i])
    sample.append(C4[i])
    data.append(sample)

miu=[]
rou=[]
Dataclass=[]
for i in range(0,3):
    datacompute=[]
    datac=[]
    for m in range(0,len(label)):
        if data[m][0]==i+1:
            datacompute.append(data[m])
            mid1=[data[m][1],data[m][2],data[m][3],data[m][4]]
            datac.append(mid1)
    miuone = []
    for j in range(0,4):
        clist=[]
        for k in range(0, len(datacompute)):
            clist.append(datacompute[k][j+1])
        miuone.append(sum(clist)/len(clist))
    miu.append(miuone)

    Dataclass.append(datac)

for i in range(0,3):
    datacompute=[]
    for m in range(0,len(label)):
        if data[m][0]==i+1:
            datacompute.append(data[m])
    rouone = []
    for j in range(0,4):
        clist=[]
        for k in range(0, len(datacompute)):
            clist.append(datacompute[k][j+1])
        rouone.append(np.var(clist))
    rou.append(rouone)


miu1=[miu[0]]
miu2=[miu[1]]
miu3=[miu[2]]

miu1=np.array(miu1)
miu2=np.array(miu2)
miu3=np.array(miu3)
miu1=miu1.T
miu2=miu2.T
miu3=miu3.T
mi=[miu1,miu2,miu3]

E=[]
for i in range(0,3):
    mind1=[]
    for j in range(0,len(Dataclass[i])):
        x=np.array([Dataclass[i][j]])
        x=x.T
        x=x-mi[i]
        mind1.append(np.dot(x,x.T))
    E.append(sum(mind1)/len(Dataclass[i]))

g=[]

for i in range(0,len(data)):
    d=[data[i][1],data[i][2],data[i][3],data[i][4]]
    d=np.array([d])
    d=d.T
    p1=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[0]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[0]).T,numpy.linalg.inv(E[0])),(d-mi[0]))))
    p2=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[1]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[1]).T,numpy.linalg.inv(E[1])),(d-mi[1]))))
    p3=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[2]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[2]).T,numpy.linalg.inv(E[2])),(d-mi[2]))))
    h=[p1,p2,p3]
    g.append(h.index(max(h))+1)

fenzi=0
fenmu=0

for i in range(0,len(data)):
    if g[i]==label[i]:
        fenzi=fenzi+1
        fenmu=fenmu+1
    else:
        fenmu=fenmu+1
print(fenzi/fenmu)


fenzi=0
fenmu=0


DF = pd.read_excel('Data_test.xlsx')
C1T = DF['C1'].values
C2T = DF['C2'].values
C3T = DF['C3'].values
C4T = DF['C4'].values

testdata=[]
for i in range(0,len(C1T)):
    test=[]
    test.append(0)
    test.append(C1T[i])
    test.append(C2T[i])
    test.append(C3T[i])
    test.append(C4T[i])
    testdata.append(test)


for i in range(0,len(testdata)):
    d=[testdata[i][1],testdata[i][2],testdata[i][3],testdata[i][4]]
    d=np.array([d])
    d=d.T
    p1=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[0]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[0]).T,numpy.linalg.inv(E[0])),(d-mi[0]))))
    p2=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[1]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[1]).T,numpy.linalg.inv(E[1])),(d-mi[1]))))
    p3=(1/(2*mt.pi*mt.sqrt(numpy.linalg.det(E[2]))))*mt.exp(0-0.5*(np.dot(np.dot((d-mi[2]).T,numpy.linalg.inv(E[2])),(d-mi[2]))))
    h=[p1,p2,p3]
    print(h.index(max(h))+1)


x=[]
for i in range(0,len(label)):
    x.append(i+1)
plt.figure(figsize=(15,6))
plt.step(x,label,c='k',label='Real Class')
plt.step(x,g,c='r',label='Predict Class')
plt.title('Prediction Result of Training Data Set Using Bayes Decision Rule',fontsize=20)
plt.xlabel('Sample No.',fontsize=20)
plt.ylabel('Class',fontsize=20)
plt.legend(fontsize=20,loc='upper left')
plt.savefig('bayes.svg',dpi=600)
plt.show()










